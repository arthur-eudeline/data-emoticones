
<!DOCTYPE html>
<html lang="fr">

    <head>
        <title>Voter pour un émoji</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, user-scalable=no">
        <link rel="icon" href="favicon.ico"/>
        <link rel="icon" type="image/png" href="favicon.png" />

        <!--FACEBOOK-->
        <meta property="og:url"                content="http://emoticones-data.tp.mmi-lepuy.fr/" />
        <meta property="og:type"               content="website" />
        <meta property="og:title"              content="Voter pour une émoticône" />
        <meta property="og:description"        content="En quelques cliques, donnez votre avis et soutenez un projet étudiant !" />
        <meta property="og:image"              content="http://emoticones-data.tp.mmi-lepuy.fr/cover.jpg" />

        <link href="css/swiper/swiper.css" rel="stylesheet">
        <link rel="stylesheet" href='css/bootstrap/bootstrap.min.css'>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/fonts.css">

        <script type="text/javascript" src="js/jquery.min.js"></script>
    </head>

    <body class="orange-template">

        <nav class="container-fluid">
            <div class="row">
                <div class="col-xs-8 col-sm-2">
                    <div class="fb-share-button" data-href="http://emoticones-data.tp.mmi-lepuy.fr" data-layout="button" data-size="large" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Femoticones-data.tp.mmi-lepuy.fr%2F&amp;src=sdkpreparse">Partager</a></div>
                </div>

                <div class="col-xs-4 text-right hide-desktop">
                    <button type="button" class=" menu-trigg" id="menu-trigg"></button>
                </div>

                <div class="col-sm-10 menu-wrapper" id="menu-wrapper">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8">
                            <ul class="row">
                                <li class="default"><a href="emo-list.php">Accueil</a></li>
                                <li class="sep no-select"></li>
                                <li class="default"><a href="index.php">Voter<span class="hide-desktop"> pour une émoticône</span></a></li>
                                <li class="sep no-select"></li>
                                <li class="default"><a href="projet.php">Le projet</a></li>
                            </ul>
                        </div>

                        <div class="col-sm-4 col-xs-12 text-right">
                                                        <div class="vote-count color-changed no-select color-change-border more-dark ">
                                <span class="color-change-text">Déjà <b>649</b> votes !</span>
                            </div>
                                                    </div>
                    </div>
                </div>

            </div>
        </nav>  


            <div class="jumbotron cover color-changed bg-change">
       <div class="container">
           <div class="row">
               <h1 class="col-xs-12 text-center color-change">Voter pour une émoticône</h1>
           </div>
        </div>
    </div>
    
        <div class="container container-box emo-box space-bet-lg text-center">
        
        <div class="emo-wrapper">
            <img alt="emoji-En colère" title="emoji-En colère" src="http://emoticones-data.tp.mmi-lepuy.fr/uploads/emojis/angry.svg" class="img-responsive emo-img">
        </div>
        
    </div>
        
    <div class="container container-box space-bet-lg">
                <div class="row">
            <h2 class="col-xs-12 col-md-6 col-md-offset-3 text-center">Associez trois mots à cet émoticône</h2>
            <p class="col-xs-12 col-md-6 col-md-offset-3 text-center">Cliquez sur les mots dans la liste ci-dessous pour associer <b>jusqu'à 3 mots</b> à cet émojis.</p>
            <p class="col-xs-12 col-md-6 col-md-offset-3 text-center">Si le mot que vous souhaitez attribuer à l'émoticône <b>ne se trouve pas dans la liste</b>, vous pouvez l'ajouter via le formulaire se trouvant ci-dessous.</p>
        </div>
        
        <div class='row'>
            <hr class="space-bet-md col-xs-12 col-md-6 col-md-offset-3">
        </div>
        
        
        <form id="search-form" class="row space-bet-md">
            <div class="col-md-6 col-md-offset-3">
                <div class="input-group">
                    
                        <input type="text" class="form-control" placeholder="Chercher ou ajouter un mot..." id="search-bar">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button" id="search_imp">Chercher</button>
                            <button class="btn btn-default disabled" type="button" id="add_imp">Ajouter</button>
                        </span>
                        
                </div>
            </div>
        </form>
        
    
        
        <form action="vote-script.php?emo-id=2" method="post" class="row visi-form">

            <!--IMPRESSIONS-->
            <div class="col-xs-12" id="buttons">

            </div>
            <!--IMPRESSIONS-->

                        <!--POPUP DE PAYS D'ORIGINE ET TOUT-->
            <div class="col-md-6 col-md-offset-3 col-xs-12 space-bet-md">
                <div class="row text-center">
                   <div class="col-xs-12">
                        <h2>
                            <span class="little"><i class="material-icons">&#xE853;</i></span>
                            Quelques précisions sur vous :
                        </h2>
                        <p>Ne vous inquiétez pas, tout est anonyme, mais j'ai besoin de quelques renseignements supplémentaires afin d'obtenir de meilleures statiques.</p>
                        <p><b>Ces informations ne vous seront demandé qu'une seule fois</b> aujourd'hui, c'est promis.</p>
                    </div>
                </div>
                
                <div class="row">
                    <hr class="row space-bet-sm">
                </div>
                  
                <ol class="row">
                    <li class="col-xs-12 space-bet-md">
                        <p>Je suis :</p>
                        <label class="col-xs-12" id="female">
                            <input type="radio" name="visi_sexe" value="femme">
                            <div>
                                <span></span>
                                Une femme
                            </div>
                        </label>

                        <label class="col-xs-12" id="male">
                            <input type="radio" name="visi_sexe" value="homme">
                            <div>
                                <span></span>
                                Un homme
                            </div>
                        </label>

                        <label class="col-xs-12" id="no-sexe">
                            <input type="radio" name="visi_sexe" value="none" checked>
                            <div>
                                <span></span>
                                Autre / Secret défense
                            </div>
                        </label>
                    </li>
                
                    <li class="col-xs-12 space-bet-md">
                        
                        <p>Tranche d'âge :</p>
                        <label class="col-xs-12">
                            <select name="age" class="form-control" required>
                                <option disabled selected value="null" >Selectionner mon âge</option>
                                <option value="_16">entre <b>10 et 16 ans</b></option>
                                <option value="17_21">entre <b>17 et 21 ans</b></option>
                                <option value="22_30">entre <b>22 et 30 ans</b></option>
                                <option value="30_39">entre <b>30 et 39 ans</b></option>
                                <option value="40_49">entre <b>40 et 49 ans</b></option>
                                <option value="50_59">entre <b>50 et 59 ans</b></option>
                                <option value="60_">plus de <b>60 ans</b></option>
                            </select>
                        </label>
                    </li>
                </ol>
            </div>
            <!--POPUP D'ORIGINE ET TOUT-->
            
            <input type="hidden" value="2" name="emo-id">
            <input type="hidden" value="http://emoticones-data.tp.mmi-lepuy.fr/index.php" name="url">
            
            <div class="col-md-6 col-md-offset-3 col-xs-12 text-center space-bet-md">
                <button type="submit" name="submit" class="btn btn-primary big-btn check">Soumettre le vote</button>
            </div>
        </form>
        </div>

    
    <!--Recherche en Ajax-->
    <script type="text/javascript">
        $(document).ready(function(){
            
            var num_res = 1;
            var add_perm = false;
            
            var searchAction = function(e){
                
                var search = $("#search-bar").val().toLowerCase();
                
                $(".button-vote").each(function(){
                    var elem = $(this).find("input");
                    var elem_label = $(this).find("label");
                    var elem_parent = $(this);
                    
//                    if( (elem.attr("id").indexOf(search) == -1) && (!$(elem).is(':checked')) ){
//                    if( (elem.attr("id").indexOf(search) == -1) ){
                    if( (elem_label.text().toLowerCase().indexOf(search) == -1) ){
                        elem_parent.addClass("hidden");
                        elem_parent.removeClass("is-shown");
                    } else {
                        elem_parent.removeClass("hidden");
                        elem_parent.addClass("is-shown");
                    }

                });
                
                num_res = $("#buttons .is-shown").length;
                
                if(num_res <= 5){
                    $("#add_imp").removeClass("disabled");
                    add_perm = true;
                } else {
                    $("#add_imp").addClass("disabled");
                    add_perm = false;
                }
            };
            
            $("#search-bar").blur(function(e){
                searchAction();
            });
            $("#search-bar").on("keypress", function(e){
                searchAction();
            });
            
            var timer;
            $("#search-bar").focusin(function(){
                timer = window.setInterval(function(){searchAction()}, 500);
            });
            
             $("#search-bar").focusout(function(){
                window.clearInterval(timer);
            });
            
            $("#search-form").submit(function(e){
                e.preventDefault();
                searchAction();
            });
            
            $("#add_imp").click(function(e){
                if(add_perm == true){
                    e.preventDefault();
                    $.ajax({
                      method: "POST",
                      url: "add-imp-script-js.php",
                      data: { add_imp : $("#search-bar").val() },
                      dataType: "json",
                    }).done(function(text){
                        if(text[0] == true){
                            $("#buttons").empty();
//                            $("#buttons").load("imp-list.php?slug="+text[1]+"&id="+text[2]+"&text="+text[3]);
                            $("#buttons").load("imp-list.php");
                            
//                            $("#search-form").val("");
                        } else {
                            window.alert(text[1]);
                        }
                    });
                } else {
                    window.alert("Vous ne pouvez pas ajouter d'impression si celle-ci existe déjà. Cherchez d'abord l'impression dans la recherche et, si votre recherche ne donne rien, vous pourrez alors ajouter la votre.")
                }               
            });
            
            $("#buttons").empty();
            $("#buttons").load("imp-list.php");
            
        });
    </script>
    <!--Recherche en Ajax-->

        <div id="fb-root"></div>
        <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = 'https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.11&appId=394086584359249';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-111336964-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-111336964-1');
        </script>


        <script>
            $(document).ready(function(){
                $("#menu-trigg").on("touch click", function(){
                    $(this).toggleClass("is-open");
                    $("#menu-wrapper").toggleClass("is-open");
                });
            });
        </script>

                <script>
            $(document).ready(function(){
                $("#cookie_close").on("touch click", function(){
                    $("#cookies").attr("style", "display:none");
                });
            });
        </script>
        <div class="cookie container-fluid" id="cookies">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-xs-12">
                            Ce site utilise des cookies à des fins purement statistiques et les données utilisées sont anonymisées. En poursuivant ma navigation, je certifie être en accord avec l'utilisation des dits cookies.
                        </div>

                        <div class="col-md-2 col-xs-12 text-center">
                            <span id="cookie_close">fermer</span>
                            <a class="btn-primary btn" href="cookies.php">En savoir plus</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
        
        <footer class="bottom">
            <div class="container">
                <p class="col-xs-12 col-md-8">Toutes les émoticônes présentes sur le site ont été créées par <a href="https://www.flaticon.com/authors/freepik">Freepik</a>, proviennent de <a href="https://www.flaticon.com/">Flaticon</a> et son disponnible <a href="https://www.flaticon.com/packs/emoji">ici</a>.</p>

                <p class="col-xs-12 col-md-4 text-right">
                    Ce site a été créé par <a href="http://arthur-eudeline.fr" target="_blank" rel="author">Arthur EUDELINE</a>.<br>
                    <a href="cookies.php">Comment et pourquoi les cookies sont utilisés sur ce site</a>
                </p>
            </div>



        </footer>
    </body>
</html>
