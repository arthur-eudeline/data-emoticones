
<!DOCTYPE html>
<html lang="fr">

    <head>
        <title>L'utilisation des cookies</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, user-scalable=no">
        <link rel="icon" href="favicon.ico"/>
        <link rel="icon" type="image/png" href="favicon.png" />

        <!--FACEBOOK-->
        <meta property="og:url"                content="http://emoticones-data.tp.mmi-lepuy.fr/" />
        <meta property="og:type"               content="website" />
        <meta property="og:title"              content="Voter pour une émoticône" />
        <meta property="og:description"        content="En quelques cliques, donnez votre avis et soutenez un projet étudiant !" />
        <meta property="og:image"              content="http://emoticones-data.tp.mmi-lepuy.fr/cover.jpg" />

        <link href="css/swiper/swiper.css" rel="stylesheet">
        <link rel="stylesheet" href='css/bootstrap/bootstrap.min.css'>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/fonts.css">

        <script type="text/javascript" src="js/jquery.min.js"></script>
    </head>

    <body class="orange-template">

        <nav class="container-fluid">
            <div class="row">
                <div class="col-xs-8 col-sm-2">
                    <div class="fb-share-button" data-href="http://emoticones-data.tp.mmi-lepuy.fr" data-layout="button" data-size="large" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Femoticones-data.tp.mmi-lepuy.fr%2F&amp;src=sdkpreparse">Partager</a></div>
                </div>

                <div class="col-xs-4 text-right hide-desktop">
                    <button type="button" class=" menu-trigg" id="menu-trigg"></button>
                </div>

                <div class="col-sm-10 menu-wrapper" id="menu-wrapper">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8">
                            <ul class="row">
                                <li class="default"><a href="emo-list.php">Accueil</a></li>
                                <li class="sep no-select"></li>
                                <li class="default"><a href="index.php">Voter<span class="hide-desktop"> pour une émoticône</span></a></li>
                                <li class="sep no-select"></li>
                                <li class="default"><a href="projet.php">Le projet</a></li>
                            </ul>
                        </div>

                        <div class="col-sm-4 col-xs-12 text-right">
                                                        <div class="vote-count color-changed no-select color-change-border more-dark ">
                                <span class="color-change-text">Déjà <b>649</b> votes !</span>
                            </div>
                                                    </div>
                    </div>
                </div>

            </div>
        </nav>  


        
<div class="jumbotron cover color-changed bg-change">
    <div class="container">
        <div class="row">
            <h1 class="col-xs-12 text-center color-change">Utilisation des Cookies</h1>
        </div>
    </div>
</div>

<div class="container space-bet-lg header-box container-box">
    <div class="row text-center">
        <h2 class="col-xs-12">À propos de l'utilisation des Cookies</h2>

        <div class="text-left">
            <p class="col-xs-12">
                Tout d'abord, les cookies <b>ne sont pas</b> utilisées à des fins commercialies ou publicitaires.
            </p>

            <p class="col-xs-12">
                Ils servent à une tâche simple mais néanmoins essentielle au bon fonctionnement du site : vous empêcher de voter plusieurs fois pour une même émoticône.
            </p>

            <p class="col-xs-12">
                Les Cookies sont en effet utilisés pour stoquer les identifiants des émoticônes pour lesquelles vous avez voté. Ainsi, le site ne vous proposera pas de vous faire voter une seconde fois pour cette émoticône et ce, dans le but de ne pas fausser les statistiques. 
            </p>

            <p class="col-xs-12">
                En résumé, ne vous inquiétez pas, les cookies utilisés pour le site sont très légers et ne comportent aucune information sensible sur votre personne. Pour preuve, le contenu des cookies du site (si vous avez déjà voté pour une émoticône) est disponnible en bas de page ! 
            </p>
        </div>

    </div>
</div>

<div class="container space-bet-lg container-box">
    <div class="row text-center">
        <h2 class="col-xs-12">Comment sont utilisés les Cookies ?</h2>

        <div class="text-left">
            <p class="col-xs-12">
                C'est très simple : les cookies utilisés stoquent deux choses.
            </p>
            
            <ul>
                <li>
                    Votre <b>identifiant</b> :
                    Même s'il est vrai que tous les votes sont <b>totalement anonymisés</b>, le besoin de savoir que vous revenez sur le site n'en reste pas moins important. Ainsi, il est nécessaire de stoquer votre "<em>identité</em>" sous forme de numéro attribué tout simplement en fonction du du nombre de visiteurs avant vous.
                </li>
                
                <li>
                    Les <b>votes que vous avez effectués</b> :
                    Il faut également stoquer les identifiants des émoticônes pour lesquelles vous avez voté. Celles-ci sont également stoquées sous forme de numéro et servent tout simplement à être "<em>mises de côté</em>" lorsque vous naviguez sur le site, afin qu'elles ne vous soient pas proposées pour un vote.
                </li>
            </ul>
            
            <p class="col-xs-12">Les cookies sont donc simplement utilisés pour que les émoticônes qui vous sont proposées ne soient que celles pour lesquelles vous n'avez pas encore votées !</p>
            
            <p class="col-xs-12">Des cookies de Google peuvent également apparaîtres, par exemple "_ga" ou "_gid" et sont liés à l'utilisation de <a href="https://www.google.com/analytics/">Google Analytics</a>, qui me permet de suivre le trafic du site. </p>

                        <p class="col-xs-12">
                <b>Désolé, mais étant donné que vous n'avez pas encore effectué de vote sur le site, aucun cookie n'est enregistré sur votre appareil.</b>
            </p>
                    </div>

    </div>
</div>


        <div id="fb-root"></div>
        <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = 'https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.11&appId=394086584359249';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-111336964-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-111336964-1');
        </script>


        <script>
            $(document).ready(function(){
                $("#menu-trigg").on("touch click", function(){
                    $(this).toggleClass("is-open");
                    $("#menu-wrapper").toggleClass("is-open");
                });
            });
        </script>

                <script>
            $(document).ready(function(){
                $("#cookie_close").on("touch click", function(){
                    $("#cookies").attr("style", "display:none");
                });
            });
        </script>
        <div class="cookie container-fluid" id="cookies">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-xs-12">
                            Ce site utilise des cookies à des fins purement statistiques et les données utilisées sont anonymisées. En poursuivant ma navigation, je certifie être en accord avec l'utilisation des dits cookies.
                        </div>

                        <div class="col-md-2 col-xs-12 text-center">
                            <span id="cookie_close">fermer</span>
                            <a class="btn-primary btn" href="cookies.php">En savoir plus</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
        
        <footer class="">
            <div class="container">
                <p class="col-xs-12 col-md-8">Toutes les émoticônes présentes sur le site ont été créées par <a href="https://www.flaticon.com/authors/freepik">Freepik</a>, proviennent de <a href="https://www.flaticon.com/">Flaticon</a> et son disponnible <a href="https://www.flaticon.com/packs/emoji">ici</a>.</p>

                <p class="col-xs-12 col-md-4 text-right">
                    Ce site a été créé par <a href="http://arthur-eudeline.fr" target="_blank" rel="author">Arthur EUDELINE</a>.<br>
                    <a href="cookies.php">Comment et pourquoi les cookies sont utilisés sur ce site</a>
                </p>
            </div>



        </footer>
    </body>
</html>
