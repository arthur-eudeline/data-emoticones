<div class='text-center buttons-wrapper'>
    <div class="button-vote">
        <input type="checkbox" value="a-bout-de-nerfs" id="a-bout-de-nerfs" data-impID="29" >
        <label for="a-bout-de-nerfs" data-impSlug="a-bout-de-nerfs" class="no-select ">À bout de nerfs</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="adorable" id="adorable" data-impID="16" >
        <label for="adorable" data-impSlug="adorable" class="no-select ">Adorable</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="agace" id="agace" data-impID="5" >
        <label for="agace" data-impSlug="agace" class="no-select ">Agacé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="ambigu" id="ambigu" data-impID="19" >
        <label for="ambigu" data-impSlug="ambigu" class="no-select ">Ambigu</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="amical" id="amical" data-impID="44" >
        <label for="amical" data-impSlug="amical" class="no-select ">Amical</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="angelique" id="angelique" data-impID="39" >
        <label for="angelique" data-impSlug="angelique" class="no-select ">Angélique</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="appeure" id="appeure" data-impID="21" >
        <label for="appeure" data-impSlug="appeure" class="no-select ">Appeuré</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="arrogant" id="arrogant" data-impID="11" >
        <label for="arrogant" data-impSlug="arrogant" class="no-select ">Arrogant</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="attendrissant" id="attendrissant" data-impID="67" >
        <label for="attendrissant" data-impSlug="attendrissant" class="no-select ">Attendrissant</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="bienveillant" id="bienveillant" data-impID="22" >
        <label for="bienveillant" data-impSlug="bienveillant" class="no-select ">Bienveillant</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="bisounours" id="bisounours" data-impID="34" >
        <label for="bisounours" data-impSlug="bisounours" class="no-select ">Bisounours</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="bisous" id="bisous" data-impID="42" >
        <label for="bisous" data-impSlug="bisous" class="no-select ">Bisous</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="bizarre" id="bizarre" data-impID="66" >
        <label for="bizarre" data-impSlug="bizarre" class="no-select ">bizarre</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="blagueur" id="blagueur" data-impID="48" >
        <label for="blagueur" data-impSlug="blagueur" class="no-select ">Blagueur</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="blase" id="blase" data-impID="31" >
        <label for="blase" data-impSlug="blase" class="no-select ">Blasé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="calme" id="calme" data-impID="38" >
        <label for="calme" data-impSlug="calme" class="no-select ">Calme</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="chelou" id="chelou" data-impID="30" >
        <label for="chelou" data-impSlug="chelou" class="no-select ">Chelou</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="chercheur" id="chercheur" data-impID="51" >
        <label for="chercheur" data-impSlug="chercheur" class="no-select ">Chercheur</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="choque" id="choque" data-impID="20" >
        <label for="choque" data-impSlug="choque" class="no-select ">Choqué</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="choupi" id="choupi" data-impID="24" >
        <label for="choupi" data-impSlug="choupi" class="no-select ">Choupi</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="con" id="con" data-impID="70" >
        <label for="con" data-impSlug="con" class="no-select ">Con</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="confus" id="confus" data-impID="72" >
        <label for="confus" data-impSlug="confus" class="no-select ">Confus</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="content" id="content" data-impID="9" >
        <label for="content" data-impSlug="content" class="no-select ">Content</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="cool" id="cool" data-impID="69" >
        <label for="cool" data-impSlug="cool" class="no-select ">Cool</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="coquin" id="coquin" data-impID="17" >
        <label for="coquin" data-impSlug="coquin" class="no-select ">Coquin</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="coquinou" id="coquinou" data-impID="60" >
        <label for="coquinou" data-impSlug="coquinou" class="no-select ">coquinou</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="decu" id="decu" data-impID="36" >
        <label for="decu" data-impSlug="decu" class="no-select ">Déçu</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="dedaigneux" id="dedaigneux" data-impID="47" >
        <label for="dedaigneux" data-impSlug="dedaigneux" class="no-select ">Dédaigneux </label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="degoute" id="degoute" data-impID="40" >
        <label for="degoute" data-impSlug="degoute" class="no-select ">Dégoûté</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="desespere" id="desespere" data-impID="28" >
        <label for="desespere" data-impSlug="desespere" class="no-select ">désespéré</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="embarasse" id="embarasse" data-impID="37" >
        <label for="embarasse" data-impSlug="embarasse" class="no-select ">embarassé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="en-colere" id="en-colere" data-impID="54" >
        <label for="en-colere" data-impSlug="en-colere" class="no-select ">En colère</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="en-pleurs" id="en-pleurs" data-impID="2" >
        <label for="en-pleurs" data-impSlug="en-pleurs" class="no-select ">En pleurs</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="endormi" id="endormi" data-impID="6" >
        <label for="endormi" data-impSlug="endormi" class="no-select ">Endormi</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="enerve" id="enerve" data-impID="41" >
        <label for="enerve" data-impSlug="enerve" class="no-select ">Énervé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="ennuye" id="ennuye" data-impID="4" >
        <label for="ennuye" data-impSlug="ennuye" class="no-select ">Ennuyé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="epuise" id="epuise" data-impID="35" >
        <label for="epuise" data-impSlug="epuise" class="no-select ">Épuisé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="etrange" id="etrange" data-impID="65" >
        <label for="etrange" data-impSlug="etrange" class="no-select ">étrange</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="excite" id="excite" data-impID="45" >
        <label for="excite" data-impSlug="excite" class="no-select ">Excité</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="frustre" id="frustre" data-impID="32" >
        <label for="frustre" data-impSlug="frustre" class="no-select ">Frustré</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="gay" id="gay" data-impID="56" >
        <label for="gay" data-impSlug="gay" class="no-select ">Gay</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="gene" id="gene" data-impID="10" >
        <label for="gene" data-impSlug="gene" class="no-select ">Gêné</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="grincheux" id="grincheux" data-impID="50" >
        <label for="grincheux" data-impSlug="grincheux" class="no-select ">Grincheux </label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="hautain" id="hautain" data-impID="46" >
        <label for="hautain" data-impSlug="hautain" class="no-select ">Hautain </label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="heureux" id="heureux" data-impID="7" >
        <label for="heureux" data-impSlug="heureux" class="no-select ">Heureux</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="inquiet" id="inquiet" data-impID="26" >
        <label for="inquiet" data-impSlug="inquiet" class="no-select ">Inquiet</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="intello" id="intello" data-impID="49" >
        <label for="intello" data-impSlug="intello" class="no-select ">Intello</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="joyeux" id="joyeux" data-impID="8" >
        <label for="joyeux" data-impSlug="joyeux" class="no-select ">Joyeux</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="kawaii" id="kawaii" data-impID="52" >
        <label for="kawaii" data-impSlug="kawaii" class="no-select ">Kawaii</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="larmoyant" id="larmoyant" data-impID="3" >
        <label for="larmoyant" data-impSlug="larmoyant" class="no-select ">Larmoyant</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="lol" id="lol" data-impID="57" >
        <label for="lol" data-impSlug="lol" class="no-select ">Lol</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="louche" id="louche" data-impID="27" >
        <label for="louche" data-impSlug="louche" class="no-select ">Louche</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="malheureux" id="malheureux" data-impID="58" >
        <label for="malheureux" data-impSlug="malheureux" class="no-select ">Malheureux</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="malsain" id="malsain" data-impID="61" >
        <label for="malsain" data-impSlug="malsain" class="no-select ">malsain</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="mech" id="mech" data-impID="53" >
        <label for="mech" data-impSlug="mech" class="no-select ">Méch</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="mechant" id="mechant" data-impID="13" >
        <label for="mechant" data-impSlug="mechant" class="no-select ">Méchant</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="mecontent" id="mecontent" data-impID="12" >
        <label for="mecontent" data-impSlug="mecontent" class="no-select ">Mécontent</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="mignon" id="mignon" data-impID="15" >
        <label for="mignon" data-impSlug="mignon" class="no-select ">Mignon</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="pedophile" id="pedophile" data-impID="62" >
        <label for="pedophile" data-impSlug="pedophile" class="no-select ">pédophile</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="penis" id="penis" data-impID="55" >
        <label for="penis" data-impSlug="penis" class="no-select ">Penis</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="perdu" id="perdu" data-impID="71" >
        <label for="perdu" data-impSlug="perdu" class="no-select ">Perdu</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="pervers" id="pervers" data-impID="18" >
        <label for="pervers" data-impSlug="pervers" class="no-select ">Pervers</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="rigolo" id="rigolo" data-impID="63" >
        <label for="rigolo" data-impSlug="rigolo" class="no-select ">rigolo</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="rire" id="rire" data-impID="64" >
        <label for="rire" data-impSlug="rire" class="no-select ">rire</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="sage" id="sage" data-impID="23" >
        <label for="sage" data-impSlug="sage" class="no-select ">Sage</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="soule" id="soule" data-impID="43" >
        <label for="soule" data-impSlug="soule" class="no-select ">Soulé</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="surpri" id="surpri" data-impID="68" >
        <label for="surpri" data-impSlug="surpri" class="no-select ">Surpri</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="suspicieux" id="suspicieux" data-impID="25" >
        <label for="suspicieux" data-impSlug="suspicieux" class="no-select ">Suspicieux</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="sympathique" id="sympathique" data-impID="14" >
        <label for="sympathique" data-impSlug="sympathique" class="no-select ">Sympathique</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="taquin" id="taquin" data-impID="33" >
        <label for="taquin" data-impSlug="taquin" class="no-select ">Taquin</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="tchatcheur" id="tchatcheur" data-impID="59" >
        <label for="tchatcheur" data-impSlug="tchatcheur" class="no-select ">Tchatcheur</label>
    </div>



    <div class="button-vote">
        <input type="checkbox" value="triste" id="triste" data-impID="1" >
        <label for="triste" data-impSlug="triste" class="no-select ">Triste</label>
    </div>


</div>
        <hr class="space-bet-md col-xs-12 col-md-6 col-md-offset-3">
          
        <div class="row">
            <h2 class="col-xs-12 text-center">Mots choisis :</h2>
            <div class="col-xs-12 col-md-10 col-md-offset-1" id="zone">

            </div>
        </div>
           
        <hr class="space-bet-md col-xs-12 col-md-6 col-md-offset-3">


<!--Ajout des bulles de votes-->
    <script type="text/javascript">
        $(document).ready(function(){
            
            var count_vote = 0;
            var vote = new Array();
            
            $("#buttons label").on("touch click", function(e){
                var nom = $(this).text();
                var $target = $(this).parent().find("input");
                if(count_vote == 3 && !$target.is(":checked")){
                    $target.prop("checked", true);
                    return ;
                }
                
                //ajout de la bulle
                if(!$target.is(":checked") && count_vote < 3){
                    
                    var impID = $target.attr("data-impID");
                    
                    $("#zone").append("<div class='"+impID+" vote col-xs-12 col-md-4 no-select' data-impID='"+impID+"'><span>"+nom+"<input type='hidden' name='vote-"+count_vote+"' value='"+impID+"'></span></div>");
                    
                    vote[count_vote] = {
                        ID : impID,
                        no : count_vote
                    }
                    
                    count_vote++; 
                    

                } else if($target.is(":checked") || $target.hasClass("checked")){
                    
                    var impID = $target.attr("data-impID");
                    for(var i = 0; i < vote.length; i++){
                        if(vote[i].ID == impID){
                            $("#zone").children()[vote[i].no].remove();
                            vote.splice(i,1)

                            for(var x = i; x < vote.length; x++){
                                vote[x].no = vote[x].no -1;
                            }
                        }
                    }
                    
                    if(count_vote > 0 && count_vote <= 3){
                        count_vote--;
                    }
                    
                }
            });
            
                            
                    });
    </script>
    <!--Fin de bulles de vote-->